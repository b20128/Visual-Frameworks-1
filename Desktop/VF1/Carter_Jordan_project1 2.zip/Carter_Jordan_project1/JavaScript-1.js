//Jordan Carter
//java script page for project 3
//Visual Frameworks 1307
// 7/18/2013

window.addEventListener("DOMContentLoaded",function(){
    
    //getElementById function
    function $(x) {
        var formInfo = document.getElementById(x);
        return formInfo;
    }
    //create select field element and populate with options
    function simpFunc(){
        var formTag = document.getElementsByTagName("myForm"),
            selectLi = $('q&a'),
            makeSelect = document.createElement('q&a');
            makeSelect.setAttribute("id","groups");
        for(var i = 0, j= ItWasA.length; i<j; i++) {
            var makeOption= document.createElement('option');
            var optText = ItWasA[i];
            makeOption.setAttribute("value", optText);
            makeOption.innerHTML = optText;
            makeSelect.appendChild(makeOption);
        }
        selectLi.appendChild(makeSelect);
    }
    
    
//find the value of selected radio button
    function getSelectedRadio() {
        var radios = document.forms[0].secrt;
        for (var i=0; i<radios.length;i++) {
            if (radios[i].checked) {
                privilegedValue=radios[i].value;
            }
            
        }
    }
//find checkbox value    
    function getCheckboxValue() {
        if ($('remember').checked) {
            rememberValue= $('remember').value
        }else{
            rememberValue= "no"
        }
    }
//toggle controls    
    function toggleControls(n){
        switch(n){
            case "on":
                $('myForm').style.disply = "none";
                $('clear').style.display = "inline";
                $('displayLink').style.display = "none";
                $('addNew').sty.display = "inline";
                break;
            case "off":
                $('myForm').style.disply = "block";
                $('clear').style.display = "inline";
                $('displayLink').style.display = "inline";
                $('addNew').sty.display = "none";
                $('items').style.display = "none";
                break;
            default:
               return false;
        }
    }
    function saveFormInfo() {
        var id          	= Math.floor(Math.random()*100000000);
        getSelectedRadio();
        getCheckboxValue();
        //gather up our values in an object.
        //object properties contain an array w/ form lable and inputs values.
        var item            = {};
            item.ItWasA     = ["What it was",$('ItWasA').value];
            item.specifics  = ["Any Specifics", $('specifics').value];
            item.important  = ["Level of Importance",$('importance').value];
            item.privileged = ["How Privileged Is This Info?",privilegedValue];
            item.remember   = ["I Remember?", rememberValue];
            item.indepth    = ["Tell Me More", $('indepth').value];
        //save data to local storage. Use stringafy to convert our objects to a string
        localStorage.setItem(id, JSON.stringify(item));
        alert("ok, got it!");
        
    }
    function displayData() {
        toggleControls("on");
        if(localStorage.length===0){
            alert("There is nothing in local storage")
        }
        var MakeDiv = doctument.createElement('div');
        makeDiv.setAttribute("id","items");
        var makeList= document.createElement('ul');
        makeDiv.appendChild(makeList);
        document.body.appendChild(makeDiv);
        $('items').style.display = "block";
        for (var i = 0, len=localStorage.length; i<len;i++) {
            var makeLi = document.createElement('li');
            var linksLi= document.createElement('li');
            makeList.appendChild(makeLi);
            var key = localStorage.key(i);
            var value = localStorage.getItem(key);
            var obj = JSON.parse(value);
            var makeSubList= document.createElement('ul');
            makeli.appendChild(makeSubList);
            for(var n in obj) {
                var makeSubli = document.createElement('li');
                makeSubList.appendChild(makeSubli);
                var optSubText = obj[n][0]+" "+obj[n][1];
                makeSubli.innerHTML = optSubText;
                makeSubList.appendChild(linksLi);
            }
            makeItemLinks(localStorage.key(i), linksLi);//create our edit and delete buttons for each action
        }
    }
    //Make Item Links
    //create the edit & delete links for each stored item
    function makeItemLinks(key, linksLi) {
        //add edit single item link
        var editLink= document.createElement('a');
        editLink.href = "#";
        editLink.key = key;
        var editLink = "Edit";
        editLink.addEventListener("click", editItem);
        editLink.innerHTML = editText;
        linksLi.appendChild(editLink);
    
    //add line break
    var breakTag= document.createElement('br');
    linksLi.appendChild(breakTag);
    
    
    //add a delete single item link    
        var deleteLink= document.createElement('a');
        deleteLink.href = "#";
        deleteLink.key = key;
        var deleteLink = "Delete";
        deleteLink.addEventListener("click", editItem);
        deleteLink.innerHTML = editText;
        linksLi.appendChild(deleteLink);
    }
    function editItems() {
        //grab the data from our item local Storage
        var value = localStorage.getitem(this.key);
        var item = JSON.parse(value);
        
        //show the form
        toggleControls("off");
        
        //populate the form fields with the current local storage values
        $('itWasA').value = item.itWasA[1];
        $('specifics').value = item.specifics[1];
        $('importance').value = item.important[1];
        var radios = document.forms[0].secrt;
        for(var i = 0; i,radios.length; i++) {
            if (radios[i].value == TopSecret && item.secrt[1] == TopSecret) {
                radios[i].setAttribut("checked", "checked");
            }else if (radios[i].value == PrivilegedInfo && item.secrt[1]== PrivilegedInfo) {
                radios[i].setAttribut("checked", "checked");
            }else if (radios[i].value ==PublicKnowledge  && item.secrt[1] == PublicKnowledge) {
                radios[i].setAttribut("checked", "checked");
            }
        }
        $('indepth').value = item.indepth[1];
        if(item.remeber[1] == "People"){
            $('remember').setAttribute("checked", "checked")
            }else if (item.remeber[1] == "Animals"){
                $('remember').setAttribute("checked", "checked");   
            }else if (item.remeber[1] == "Colors") {
                $('remember').setAttribute("checked", "checked");
            }else if (item.remeber[1] == "Feelings") {
                $('remember').setAttribute("checked", "checked");
            }else if (item.remeber[1] == "Images") {
                $('remember').setAttribute("checked", "checked");
            }
        
    }
    
    function clearLocal(){
        if (localStorage.length===0) {
            alert("there is no data to clear")
        }else{
            localStorage.clear();
            alert("All data cleared.")
            window.location.reload();
            return false;
        }
    }
//Variables    
    var itWasA = ["Dream","Idea","song", "Not Sure"],
        privilegedValue,
    	rememberValue = "No";
    	simpFunc();
    
    
    //set Link & submit Click Events
    
    var displayLink = $('displayData');
    displayLink.addEventListener("click", displayData);
    var clearLink = $('clear');
    clearLink.addEventListener("click",clearLocal);
    var save = $('submit');
    save.addEventListener("click", submit);

}
);

